		<div class="row">
			<dl class="sub-nav">
			  <dt>Listings:</dt>
			  <dd><a href="http://localhost/eeod/s/">All</a></dd>
			  <dd><a href="http://localhost/eeod/product-category/6/">Concentrate</a></dd>
			  <dd><a href="http://localhost/eeod/product-category/5/">Edible</a></dd>
			  <dd><a href="http://localhost/eeod/product-category/4/">Hybrid</a></dd>
			  <dd><a href="http://localhost/eeod/product-category/2/">Indica</a></dd>
			  <dd><a href="http://localhost/eeod/product-category/3/">Sativa</a></dd>
			  <dd><a href="http://localhost/eeod/product-category/9/">Tincture</a></dd>
			  <dd><a href="http://localhost/eeod/product-category/7/">Drinks</a></dd>
			</dl>
		</div>